from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "main.login"
login_manager.login_message_category = "info"

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)

    from app.routes import main
    app.register_blueprint(main)

    with app.app_context():
        from app import models
        db.create_all()
        seed_categories()

    return app

def seed_categories():
    from app.models import Category
    defaults = [
        ("Food", "#F97316", "expense"), ("Transport", "#0EA5E9", "expense"),
        ("Shopping", "#8B5CF6", "expense"), ("Bills", "#EF4444", "expense"),
        ("Education", "#14B8A6", "expense"), ("Health", "#EC4899", "expense"),
        ("Entertainment", "#6366F1", "expense"), ("Other", "#64748B", "expense"),
    ]
    for name, color, kind in defaults:
        if not Category.query.filter_by(name=name, type=kind).first():
            db.session.add(Category(name=name, color=color, type=kind))
    db.session.commit()
