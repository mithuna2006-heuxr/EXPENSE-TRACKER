from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from io import BytesIO
import json
import calendar

from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file, Response
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import func, extract, or_

from app import db
from app.models import User, Category, Expense, Income, Budget, SavingsGoal

main = Blueprint("main", __name__)

def money(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0.00")

def parse_date(value, fallback=None):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return fallback or date.today()

def owned_expense(expense_id):
    return Expense.query.filter_by(id=expense_id, user_id=current_user.id).first_or_404()

def owned_income(income_id):
    return Income.query.filter_by(id=income_id, user_id=current_user.id).first_or_404()

def month_bounds(year, month):
    last_day = calendar.monthrange(year, month)[1]
    return date(year, month, 1), date(year, month, last_day)

def totals_for_month(year, month):
    start, end = month_bounds(year, month)
    income = db.session.query(func.coalesce(func.sum(Income.amount), 0)).filter(
        Income.user_id == current_user.id, Income.date >= start, Income.date <= end
    ).scalar()
    expenses = db.session.query(func.coalesce(func.sum(Expense.amount), 0)).filter(
        Expense.user_id == current_user.id, Expense.date >= start, Expense.date <= end
    ).scalar()
    return Decimal(str(income)), Decimal(str(expenses))

@main.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("main.login"))

@main.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if len(username) < 3:
            flash("Username must be at least 3 characters.", "danger")
        elif "@" not in email or "." not in email:
            flash("Enter a valid email address.", "danger")
        elif len(password) < 8:
            flash("Password must contain at least 8 characters.", "danger")
        elif password != confirm:
            flash("Passwords do not match.", "danger")
        elif User.query.filter(or_(User.username == username, User.email == email)).first():
            flash("That username or email is already registered.", "danger")
        else:
            user = User(username=username, email=email, currency="INR")
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Account created. Welcome!", "success")
            return redirect(url_for("main.dashboard"))
    return render_template("register.html")

@main.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter(or_(User.username == identity, User.email == identity.lower())).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for("main.dashboard"))
        flash("Invalid username/email or password.", "danger")
    return render_template("login.html")

@main.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.login"))

@main.route("/dashboard")
@login_required
def dashboard():
    today = date.today()
    year, month = today.year, today.month
    income, expenses = totals_for_month(year, month)
    recent = Expense.query.filter_by(user_id=current_user.id).order_by(Expense.date.desc(), Expense.id.desc()).limit(6).all()
    budgets = Budget.query.filter_by(user_id=current_user.id, year=year, month=month).all()
    budget_cards = []
    for b in budgets:
        spent = db.session.query(func.coalesce(func.sum(Expense.amount), 0)).filter(
            Expense.user_id == current_user.id, Expense.category_id == b.category_id,
            extract("month", Expense.date) == month, extract("year", Expense.date) == year
        ).scalar()
        spent = Decimal(str(spent))
        budget_cards.append({"budget": b, "spent": spent, "percent": min(100, int(spent / b.amount * 100)) if b.amount else 0})
    category_rows = db.session.query(Category.name, Category.color, func.sum(Expense.amount)).join(
        Expense, Expense.category_id == Category.id
    ).filter(Expense.user_id == current_user.id, extract("month", Expense.date) == month,
             extract("year", Expense.date) == year).group_by(Category.id, Category.name, Category.color).all()
    monthly_labels, monthly_income, monthly_expenses = [], [], []
    for offset in range(5, -1, -1):
        idx = year * 12 + month - 1 - offset
        y, m = idx // 12, idx % 12 + 1
        inc, exp = totals_for_month(y, m)
        monthly_labels.append(calendar.month_abbr[m])
        monthly_income.append(float(inc))
        monthly_expenses.append(float(exp))
    return render_template("dashboard.html", income=income, expenses=expenses, balance=income-expenses,
        recent=recent, budget_cards=budget_cards, category_labels=[r[0] for r in category_rows],
        category_values=[float(r[2] or 0) for r in category_rows], category_colors=[r[1] for r in category_rows],
        monthly_labels=monthly_labels, monthly_income=monthly_income, monthly_expenses=monthly_expenses,
        month_name=calendar.month_name[month], today=today)

@main.route("/expenses", methods=["GET", "POST"])
@login_required
def expenses():
    categories = Category.query.filter_by(type="expense").order_by(Category.name).all()
    if request.method == "POST":
        category_id = request.form.get("category_id", type=int)
        category = Category.query.filter_by(id=category_id, type="expense").first()
        amount = money(request.form.get("amount"))
        description = request.form.get("description", "").strip()
        if not category or amount <= 0 or not description:
            flash("Enter a description, a positive amount, and a valid category.", "danger")
        else:
            item = Expense(user_id=current_user.id, category_id=category.id, amount=amount,
                description=description[:200], date=parse_date(request.form.get("date")),
                payment_method=request.form.get("payment_method", "UPI")[:50],
                notes=request.form.get("notes", "").strip() or None)
            db.session.add(item)
            db.session.commit()
            flash("Expense added successfully.", "success")
            return redirect(url_for("main.expenses"))
    query = Expense.query.filter_by(user_id=current_user.id)
    search = request.args.get("q", "").strip()
    category_filter = request.args.get("category", type=int)
    if search:
        query = query.filter(Expense.description.ilike(f"%{search}%"))
    if category_filter:
        query = query.filter_by(category_id=category_filter)
    items = query.order_by(Expense.date.desc(), Expense.id.desc()).all()
    return render_template("expenses.html", expenses=items, categories=categories, search=search, category_filter=category_filter)

@main.route("/expenses/<int:expense_id>/edit", methods=["GET", "POST"])
@login_required
def edit_expense(expense_id):
    item = owned_expense(expense_id)
    categories = Category.query.filter_by(type="expense").order_by(Category.name).all()
    if request.method == "POST":
        category = Category.query.filter_by(id=request.form.get("category_id", type=int), type="expense").first()
        amount = money(request.form.get("amount"))
        description = request.form.get("description", "").strip()
        if not category or amount <= 0 or not description:
            flash("Enter a description, positive amount and valid category.", "danger")
        else:
            item.category_id = category.id
            item.amount = amount
            item.description = description[:200]
            item.date = parse_date(request.form.get("date"))
            item.payment_method = request.form.get("payment_method", "UPI")[:50]
            item.notes = request.form.get("notes", "").strip() or None
            db.session.commit()
            flash("Expense updated.", "success")
            return redirect(url_for("main.expenses"))
    return render_template("edit_expense.html", item=item, categories=categories)

@main.route("/expenses/<int:expense_id>/delete", methods=["POST"])
@login_required
def delete_expense(expense_id):
    item = owned_expense(expense_id)
    db.session.delete(item)
    db.session.commit()
    flash("Expense deleted.", "success")
    return redirect(url_for("main.expenses"))

@main.route("/income", methods=["GET", "POST"])
@login_required
def income():
    if request.method == "POST":
        source = request.form.get("source", "").strip()
        amount = money(request.form.get("amount"))
        if not source or amount <= 0:
            flash("Enter an income source and a positive amount.", "danger")
        else:
            db.session.add(Income(user_id=current_user.id, source=source[:100], amount=amount,
                date=parse_date(request.form.get("date")), notes=request.form.get("notes", "").strip() or None))
            db.session.commit()
            flash("Income added successfully.", "success")
            return redirect(url_for("main.income"))
    items = Income.query.filter_by(user_id=current_user.id).order_by(Income.date.desc(), Income.id.desc()).all()
    return render_template("income.html", incomes=items)

@main.route("/income/<int:income_id>/delete", methods=["POST"])
@login_required
def delete_income(income_id):
    item = owned_income(income_id)
    db.session.delete(item)
    db.session.commit()
    flash("Income entry deleted.", "success")
    return redirect(url_for("main.income"))

@main.route("/budgets", methods=["GET", "POST"])
@login_required
def budgets():
    today = date.today()
    categories = Category.query.filter_by(type="expense").order_by(Category.name).all()
    if request.method == "POST":
        category = Category.query.filter_by(id=request.form.get("category_id", type=int), type="expense").first()
        amount = money(request.form.get("amount"))
        month = request.form.get("month", type=int)
        year = request.form.get("year", type=int)
        if not category or amount <= 0 or not month or month < 1 or month > 12 or not year or year < 2000 or year > 2200:
            flash("Enter a valid category, budget amount, month and year.", "danger")
        else:
            existing = Budget.query.filter_by(user_id=current_user.id, category_id=category.id, month=month, year=year).first()
            if existing:
                existing.amount = amount
                existing.notes = request.form.get("notes", "").strip() or None
            else:
                db.session.add(Budget(user_id=current_user.id, category_id=category.id, amount=amount,
                    month=month, year=year, notes=request.form.get("notes", "").strip() or None))
            db.session.commit()
            flash("Budget saved.", "success")
            return redirect(url_for("main.budgets"))
    items = Budget.query.filter_by(user_id=current_user.id).order_by(Budget.year.desc(), Budget.month.desc()).all()
    budget_rows = []
    for b in items:
        start, end = month_bounds(b.year, b.month)
        spent = db.session.query(func.coalesce(func.sum(Expense.amount), 0)).filter(
            Expense.user_id == current_user.id, Expense.category_id == b.category_id,
            Expense.date >= start, Expense.date <= end).scalar()
        spent = Decimal(str(spent))
        budget_rows.append({"budget": b, "spent": spent, "remaining": b.amount-spent,
                            "percent": min(100, int(spent/b.amount*100)) if b.amount else 0})
    return render_template("budgets.html", categories=categories, budget_rows=budget_rows, today=today, months=list(enumerate(calendar.month_name))[1:])

@main.route("/savings", methods=["GET", "POST"])
@login_required
def savings():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        target = money(request.form.get("target_amount"))
        saved = money(request.form.get("saved_amount") or 0)
        if not name or target <= 0 or saved < 0:
            flash("Enter a goal name, positive target and non-negative saved amount.", "danger")
        else:
            db.session.add(SavingsGoal(user_id=current_user.id, name=name[:100], target_amount=target,
                saved_amount=min(saved, target), target_date=parse_date(request.form.get("target_date")) if request.form.get("target_date") else None,
                notes=request.form.get("notes", "").strip() or None))
            db.session.commit()
            flash("Savings goal added.", "success")
            return redirect(url_for("main.savings"))
    goals = SavingsGoal.query.filter_by(user_id=current_user.id).order_by(SavingsGoal.created_at.desc()).all()
    return render_template("savings.html", goals=goals)

@main.route("/savings/<int:goal_id>/add", methods=["POST"])
@login_required
def add_savings(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    contribution = money(request.form.get("contribution"))
    if contribution <= 0:
        flash("Contribution must be greater than zero.", "danger")
    else:
        goal.saved_amount = min(goal.target_amount, goal.saved_amount + contribution)
        db.session.commit()
        flash("Savings contribution recorded.", "success")
    return redirect(url_for("main.savings"))

@main.route("/savings/<int:goal_id>/delete", methods=["POST"])
@login_required
def delete_savings(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    db.session.delete(goal)
    db.session.commit()
    flash("Savings goal deleted.", "success")
    return redirect(url_for("main.savings"))

@main.route("/reports")
@login_required
def reports():
    today = date.today()
    year = request.args.get("year", today.year, type=int)
    month = request.args.get("month", today.month, type=int)
    if year < 2000 or year > 2200: year = today.year
    if month < 1 or month > 12: month = today.month
    start, end = month_bounds(year, month)
    income_total, expense_total = totals_for_month(year, month)
    category_rows = db.session.query(Category.name, func.sum(Expense.amount)).join(
        Expense, Expense.category_id == Category.id).filter(Expense.user_id == current_user.id,
        Expense.date >= start, Expense.date <= end).group_by(Category.id, Category.name).order_by(func.sum(Expense.amount).desc()).all()
    expense_items = Expense.query.filter(Expense.user_id == current_user.id, Expense.date >= start, Expense.date <= end).order_by(Expense.date.desc()).all()
    return render_template("reports.html", year=year, month=month, month_name=calendar.month_name[month],
        income_total=income_total, expense_total=expense_total, net=income_total-expense_total,
        category_labels=[r[0] for r in category_rows], category_values=[float(r[1] or 0) for r in category_rows],
        expense_items=expense_items, months=list(enumerate(calendar.month_name))[1:])

@main.route("/reports/export.xlsx")
@login_required
def export_excel():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    today = date.today()
    year = request.args.get("year", today.year, type=int)
    month = request.args.get("month", today.month, type=int)
    if year < 2000 or year > 2200 or month < 1 or month > 12:
        flash("Invalid report month.", "danger")
        return redirect(url_for("main.reports"))
    start, end = month_bounds(year, month)
    expenses_list = Expense.query.filter(Expense.user_id == current_user.id, Expense.date >= start, Expense.date <= end).order_by(Expense.date).all()
    incomes_list = Income.query.filter(Income.user_id == current_user.id, Income.date >= start, Income.date <= end).order_by(Income.date).all()
    wb = Workbook()
    ws = wb.active
    ws.title = "Expenses"
    ws.append(["Date", "Description", "Category", "Payment method", "Amount (INR)"])
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="166534")
    for item in expenses_list:
        ws.append([item.date.isoformat(), item.description, item.category_ref.name, item.payment_method, float(item.amount)])
    wi = wb.create_sheet("Income")
    wi.append(["Date", "Source", "Amount (INR)"])
    for cell in wi[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="166534")
    for item in incomes_list:
        wi.append([item.date.isoformat(), item.source, float(item.amount)])
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        for col in sheet.columns:
            letter = col[0].column_letter
            sheet.column_dimensions[letter].width = min(34, max(14, max(len(str(c.value or "")) for c in col) + 2))
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=f"budget-report-{year}-{month:02}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@main.route("/reports/export.pdf")
@login_required
def export_pdf():
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    today = date.today()
    year = request.args.get("year", today.year, type=int)
    month = request.args.get("month", today.month, type=int)
    if year < 2000 or year > 2200 or month < 1 or month > 12:
        flash("Invalid report month.", "danger")
        return redirect(url_for("main.reports"))
    start, end = month_bounds(year, month)
    inc, exp = totals_for_month(year, month)
    items = Expense.query.filter(Expense.user_id == current_user.id, Expense.date >= start, Expense.date <= end).order_by(Expense.date).all()
    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, title="Expense and Budget Report")
    styles = getSampleStyleSheet()
    story = [Paragraph(f"Expense &amp; Budget Tracker — {calendar.month_name[month]} {year}", styles["Title"]),
             Spacer(1, 12), Paragraph(f"Total income: INR {inc:,.2f}", styles["Normal"]),
             Paragraph(f"Total expenses: INR {exp:,.2f}", styles["Normal"]),
             Paragraph(f"Net balance: INR {inc-exp:,.2f}", styles["Normal"]), Spacer(1, 18)]
    data = [["Date", "Description", "Category", "Amount (INR)"]]
    data += [[i.date.isoformat(), i.description[:35], i.category_ref.name, f"{i.amount:,.2f}"] for i in items]
    table = Table(data, repeatRows=1, colWidths=[75, 190, 100, 90])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#166534")),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("GRID",(0,0),(-1,-1),0.4,colors.lightgrey),("PADDING",(0,0),(-1,-1),6),
        ("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(table)
    doc.build(story)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=f"budget-report-{year}-{month:02}.pdf", mimetype="application/pdf")
