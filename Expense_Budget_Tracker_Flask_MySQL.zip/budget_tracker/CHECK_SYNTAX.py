import ast, pathlib
root=pathlib.Path(__file__).parent
files=list(root.rglob('*.py'))
for p in files:
    ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
    print('OK:', p.relative_to(root))
print(f'Checked {len(files)} Python files.')
