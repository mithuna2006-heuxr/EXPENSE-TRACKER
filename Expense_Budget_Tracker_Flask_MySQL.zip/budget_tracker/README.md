# PaisaPlan — Expense & Budget Tracker

**Internship task:** PY-FN-002  
**Stack:** Python, Flask, Flask-SQLAlchemy, MySQL, Bootstrap 5, Chart.js  
**Currency:** INR (₹)

A responsive personal-finance web app for recording expenses and income, planning monthly category budgets, tracking savings goals, and exporting monthly reports as PDF or Excel.

## Features
- User registration, login and logout; passwords are hashed.
- Per-user expense CRUD, categories, payment methods, search and filtering.
- Income tracking.
- Monthly category budgets and spending progress.
- Savings goals with contributions.
- Dashboard with six-month cash flow and category charts.
- Monthly financial reports with PDF and Excel export.
- INR display and responsive Bootstrap interface.

## Requirements
- Python 3.10 or newer recommended
- MySQL Server 8.x and MySQL Workbench
- VS Code
- Git (for GitHub submission)

## Setup on Windows
1. Open this folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Create and activate the virtual environment:
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, run `venv\\Scripts\\activate.bat` from Command Prompt instead.
4. Install packages:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. In MySQL Workbench, run:
   ```sql
   CREATE DATABASE budget_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'budget_user'@'localhost' IDENTIFIED BY 'Choose_A_Strong_Password';
   GRANT ALL PRIVILEGES ON budget_db.* TO 'budget_user'@'localhost';
   ```
   If that MySQL user already exists, do not run `CREATE USER` again; update its password or use the account you already have.
6. Copy `.env.example` to `.env`. Replace `YOUR_PASSWORD` in `DATABASE_URL` with the password you chose. Replace `SECRET_KEY` with a long random secret. URL-encode special characters in the database password if necessary.
7. Run the app:
   ```powershell
   python run.py
   ```
8. Open `http://127.0.0.1:5000` in your browser and create an account.

The tables and starter expense categories are created automatically when the application starts.

## Main routes
- `/register` — create an account
- `/login` — sign in
- `/dashboard` — overview and charts
- `/expenses` — add, edit, delete and search expenses
- `/income` — track income
- `/budgets` — manage monthly budgets
- `/savings` — savings goals and contributions
- `/reports` — monthly reports and exports

## Database tables
`user`, `category`, `expense`, `income`, `budget`, `savings_goal`

## Important notes
- Do not commit `.env`, database passwords, or real financial data to GitHub.
- This is an educational project starter. Before public deployment, add/verify CSRF protection on every state-changing form, secure cookie settings, database migrations, rate limiting, production error handling, HTTPS, and automated tests. Do not run Flask's debug server in production.
- Report charts use Chart.js via a CDN, so an internet connection is needed for the chart library.
- This starter uses a simple default category list shared across accounts. User-entered financial records are scoped to the logged-in user.

## Suggested screenshots for submission
1. Login
2. Registration
3. Dashboard
4. Expense list and add form
5. Income page
6. Budgets
7. Savings goals
8. Monthly report and charts
9. Exported Excel/PDF sample

## GitHub
```powershell
git init
git add .
git commit -m "Build PaisaPlan expense and budget tracker"
```
Create a new repository on GitHub, then follow GitHub's instructions to add the remote and push the project. Confirm `.env` is ignored before pushing.
